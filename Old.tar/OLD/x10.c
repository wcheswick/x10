/*
 * talk to the smarthome controller.  Protocol is miss-documented
 * in http://www.smarthome.com/protocol.txt.  My device appears to
 * be like a CM11.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <bstring.h>
#include <sys/time.h>
#include <sys/signal.h>

#include "arg.h"
#include "x10.h"

int debug = 0;

#define TESTHOUSE	'C'
#define A(h, d)	((c2b[h - 'A']<<4) | (c2b[d-1] & 0x0f))

uchar c2b[] = {
	6, 14, 2, 10, 1, 9, 5, 13,
	7, 15, 3, 11, 0, 8, 4, 12};

uchar b2c[] = {
	12, 4, 2, 10, 14, 6, 0, 8,
	13, 5, 3, 11, 15, 7, 1, 9};

enum {
	AllOff,
	AllOn,
	On,
	Off,
	Dim,
	Bright,
	AllLightsOff,
	ExtendedCode,
	HailReq,
	HailAck,
	PresetDim1,
	PresetDim2,
	ExtDataTrans,
	StatusOn,
	StatusOff,
	StatusReq
} Funcs;

char *cmds[] = {
	"AllOff",
	"AllOn",
	"On",
	"Off",
	"Dim",
	"Bright",
	"AllLightsOff",
	"ExtendedCode",
	"HailReq",
	"HailAck",
	"PresetDim1",
	"PresetDim2",
	"ExtDataTrans",
	"StatusOn",
	"StatusOff",
	"StatusReq"
};

#define Poll	0x5a	/* terminal poll, data waiting */

void answer_poll(void);

int
input(int sec) {
	struct timeval to;
	fd_set fdset;
	int n;

	to.tv_sec = sec;
	to.tv_usec = 0;
	FD_ZERO(&fdset);
	FD_SET(x10port, &fdset);
	n = select(x10port+1, &fdset, 0, 0, &to);
	if (n < 0) {
		perror("input, select");
		exit(1);
	}
	return n > 0;
}

#define	RESPONSE_TO	10

int
readbyte(void) {
	uchar ans[1];
	int n;

	if (!input(RESPONSE_TO)) {
		fprintf(stderr, "readbyte timed out\n");
		return -1;
	}

	if ((n = read(x10port, &ans, 1)) != 1) {
		perror("readbyte read");
		exit(1);
	}
	if (debug > 1)
		fprintf(stderr, "***> 0x%0.2x\n", ans[0]);
	return ans[0];
}

int
read_expected(unsigned int ack) {
	int ch;

	if ((ch=readbyte()) == ack)
		return 1;
	if (ch == Poll) {
		answer_poll();
		return 1;
	}
	if (ch < 0)
		fprintf(stderr, "read timed out, expecting 0x%0.2x\n",
			ack);
	else
		fprintf(stderr, "read_expected 0x%0.2x, got 0x%0.2x\n",
			ack, ch);
	return 0;
}

unsigned int checksum;

void
sendbyte(uchar b) {
	int n;

	if (debug > 1)
		fprintf(stderr, "<--- 0x%0.2x\n", b);
	checksum += b;
	n = write(x10port, &b, 1);
	if (n != 1) {
		perror("sendbyte");
		exit(1);
	}
}

void
send(uchar *buf, int len) {
	int i;

	for (i=0; i<len; i++)
		sendbyte(buf[i]);
}

void
stuff(void) {
	int i;

	for (i=0; i<256; i++) {
		if (input(1))
			break;
		sendbyte(i);
	}
}

void
sendmsg(int b1, int b2) {
	int n;

	do {
		checksum = 0;
		sendbyte(b1);
		sendbyte(b2);
		sendbyte(0);
		sendbyte(0);
	} while (!read_expected(checksum & 0xff));
	sendbyte(0x00);
	if (!read_expected(0x55))
		fprintf(stderr, "sendaddr, device not ready\n");
}

#define Addr	0x04
#define Func	0x02
#define Ext	0x01

void
on(int house, int device) {
	int addrc = A(house,device);

	if (debug)
		fprintf(stderr, "on %c%d\n", house, device);
	sendmsg(Addr, addrc);
	sendmsg(Func|Addr, (addrc & 0xf0) | On);
}

void
off(int house, int device) {
	int addrc = A(house,device);

	if (debug)
		fprintf(stderr, "off %c%d\n", house, device);
	sendmsg(Addr, addrc);
	sendmsg(Func|Addr, (addrc & 0xf0) | Off);
}

void
dim(int house, int device, int v) {
	int addrc = A(house,device);

	if (debug)
		fprintf(stderr, "dim %c%d 0x%0.2x %d\n",
			house, device, v, v);
	sendmsg(Addr, addrc);
	sendmsg(((v & 0x1f) << 3) | Func | Addr, (addrc & 0xf0) | Dim);
}

void
brighten(int house, int device, int v) {
	int addrc = A(house,device);

	if (debug)
		fprintf(stderr, "brighten %c%d 0x%0.2x %d\n",
			house, device, v, v);
	sendmsg(Addr, addrc);
	sendmsg(((v & 0x1f) << 3) | Func | Addr, (addrc & 0xf0) | Bright);
}

void
answer_timereq(void) {
	struct tm *t;
	clock_t c = clock();
	int i, n, jdate;

	t = localtime(&c);
	jdate = t->tm_yday + 1;
	sendbyte(0x9b);	/* timer download header */
	checksum = 0;
	sendbyte(t->tm_sec);
	sendbyte(t->tm_min + 60*(t->tm_hour % 1));
	sendbyte(t->tm_hour/2);
	sendbyte(jdate % 256);
	sendbyte((((jdate / 256) & 0x01)<<7) | t->tm_wday);
	sendbyte(A(TESTHOUSE, 0));

	read_expected(checksum & 0xff);
	sendbyte(0x00);
	read_expected(0x55);
}

#define	HOUSE(rc)	('A' + b2c[((rc)>>4) & 0xf])
#define	DEVICE(rc)	(b2c[(rc) & 0xf] + 1)

/*
 * We were polled, data is available.  Get it.
 */
void
answer_poll(void) {
	uchar response[256];
	int i, n;
	int r1, r2, r3;

	sendbyte(0xc3);
	sendbyte(0x00);
	sendbyte(0x00);
	sendbyte(0x00);

	n = readbyte();
	if (n < 0)
		return;
	for (i=0; i<n; i++) {
		int r = readbyte();
		if (r < 0)
			return;
		response[i] = r;
	}
	if (debug) {
		fprintf(stderr, "event: ");
		for (i=1; i<n; i++) {
			if ((response[0] >> ((i-1)) & 0x01)) {/* function */
				fprintf(stderr, "%s(%c) ",
					cmds[response[i] & 0xf],
					HOUSE(response[i]));
				switch (response[i] & 0xf) {
				case Bright:
				case Dim:
					fprintf(stderr, "0x%0.2x (%d%%) ",
						response[i+1],
						(response[i+1]*100)/210);
					i++;
					break;
				}
			} else
				fprintf(stderr, "%c%1d ",
					HOUSE(response[i]),
					DEVICE(response[i]));
		}
		fprintf(stderr, "\n");
	}
}

void
check_poll(void) {
	uchar ans;
	int n;

	if (debug > 1)
		fprintf(stderr, "checking poll\n");
	if (!input(0))
		return;
	ans = readbyte();
	switch (ans) {
	case 0xa5:
		if (debug)
			fprintf(stderr, "* setting time\n");
		answer_timereq();
		break;
	case Poll:
		answer_poll();
		break;
	case -1:	/* read timed out */
		break;
	default:
		fprintf(stderr, "check_poll: unexpected poll! 0x%0.2x\n",
			ans);
	}
}

void
status(void) {
	uchar buf[1];
	int i;

	sendbyte(0x8b);
	fprintf(stderr, "status: \n");
	for (i=0; i<10; i++)
		fprintf(stderr, "0x%0.2x ", (0xff & readbyte()));
	fprintf(stderr, "\n");
}

void
disable_ring(void) {
	sendbyte(0xdb);
	read_expected(0xdb);
	sendbyte(0x00);
	read_expected(0x55);
}

/*
 * determine our next pattern.  We have esthetic constraints.
 * Strings 0 and 1 are on one post, 2 and 3 on the other.
 */
int
selecttarget(int old) {
	int target;

	while (1) {
		target = rand() & 0xf;
		/*
		 * It must change.
		 */
		if (target == old) /* we must change */
			continue;
		/*
		 * Each post must have at least one string on.
		 */
		if (!(target & 0x3) || !(target & 0xc))
			continue;
		break;
	}
	return target;
}

int running = 1;

/* shut down */
void
times_up(void) {
	if (debug)
		fprintf(stderr, "Times up!\n");
	running = 0;
}

void
interesting(void) {
	int target, old = 0xf;	/*start with all four strings on */
	int i, j;

	srand(clock());
	on(TESTHOUSE, 1);	/* start with the four on */
	sleep(1);
	on(TESTHOUSE, 3);	/*staggered start, for interest */
	sleep(1);
	on(TESTHOUSE, 2);
	sleep(1);
	on(TESTHOUSE, 4);
	sleep(1);

	while (running) {
		target = selecttarget(old);
		for (i=0; i<15; i++) {	/* dimming iterations */
			for (j=0; j<4; j++) { /*advance each string*/
				int mask = 1 << j;
				if (((old ^ target) & mask) == 0)
					continue;
				if (target & mask)
					brighten(TESTHOUSE, j+1, 2);
				else
					dim(TESTHOUSE, j+1, 2);
			}
		}
		sleep(155);
		old = target;
	}
	off(TESTHOUSE, 1);
	sleep(1);
	off(TESTHOUSE, 3);
	sleep(1);
	off(TESTHOUSE, 2);
	sleep(1);
	off(TESTHOUSE, 4);
}

int
usage(void) {
	fprintf(stderr, "usage: x10 [-d] [hours]\n");
	return 1;
}
	
int
main(int argc, uchar *argv[]) {
	int i;

	ARGBEGIN {
	case 'd': debug++;	break;
	default:
		return(usage());
	} ARGEND;

	if (argc == 1) {
		int limit = atoi(argv[0]);
		if (limit == 0)
			return(usage());
		
		signal(SIGALRM, times_up);
		alarm(limit*3600);
	}
		
	setup_tty();

	if (input(2))	/* handle pending polls */
		check_poll();

	interesting();
}
