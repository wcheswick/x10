
#include <stdio.h>

#include "x10.h"

int
main(int argc, char *argv[]) {
	char b;
	int n, c=0;

	setup_tty();
	while ((n = read(tty, &b, 1)) > 0) {
		fprintf(stderr, "0x%0.2x ", (0xff & b));
		if (++c == 16) {
			c = 0/*, fprintf(stderr, "\n")*/;
		}
	}
	fprintf(stderr, "\n");
	perror("eof");
}
